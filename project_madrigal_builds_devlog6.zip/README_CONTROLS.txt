Hi, I apologize for the bare bones build and lack of UI/controls. There is no way to exit the game, so you must use Alt Tab or some other 
OS method to get out. 

WASD - Move character 
Mouse Movement - Moves Camera 
Space - Flys (makes character move upward) 
X - Changes planet geometry between sphere and fractal (holding this makes it go back and forth) 
U, I - Hold these to to decrease and increase fractal subdivision amount respectively 
J, K - Hold these to decrease and increase modulo offset for the fractal respectively